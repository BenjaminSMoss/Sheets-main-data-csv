
XPS data shows raw EB folowed by EB after C 1s calibration to 284.8 eV

In DFT STO, Rh:STO and La,Rh:STO all have differnt VB minima due to the
introduction of new states. Thus all have different 0K Ef positions
DFT data was calibrated to the CB edge, the potential of which we calcualte
to be unaffected by doping.

SEC was repeated twice with samples from two batches to make sure the effects
observed was reproducable. For simplicity, only one set of SEC data is provided
here. To get the sigmoidal plots shown normalise against 0 or -0.2 V RHE (i.e.
divide everything else by the negative abs value at 590 nm at this potential)

TAS and PIA data is relativley straghtforward.

If you have any problems, questions or would like any additional data please do not 
hisitate to contact me!  I would be delighted start a correspondance:
b.moss14@imperial.ac.uk, benjamin.moss@ymail.com

"The idea is like grass: it craves light, likes crowds, thrives on crossbreeding,
 grows stronger from being stepped on. ~ Ursula K. Le Guin"

